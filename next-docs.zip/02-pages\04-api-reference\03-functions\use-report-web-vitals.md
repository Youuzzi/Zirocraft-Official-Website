---
title: useReportWebVitals
description: Use the Next.js `useReportWebVitals` hook to send Core Web Vitals and custom performance metrics to analytics.
source: app/api-reference/functions/use-report-web-vitals
---

{/* DO NOT EDIT. The content of this doc is generated from the source above. To edit the content of this page, navigate to the source page in your editor. You can use the `<PagesOnly>Content</PagesOnly>` component to add content that is specific to the Pages Router. Any shared content should not be wrapped in a component. */}
