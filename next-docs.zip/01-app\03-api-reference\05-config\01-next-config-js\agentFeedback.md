---
title: agentFeedback
description: Enable a review flow for Next.js issue reports prepared by AI coding agents.
version: experimental
related:
  links:
    - app/guides/ai-agents
    - app/api-reference/config/next-config-js/agentRules
---

The `experimental.agentFeedback` option controls whether `next dev` creates and updates instructions that let detected AI coding agents prepare Next.js issue reports for your review. It is disabled by default and requires [Next.js Telemetry](/telemetry) to be enabled. Agent feedback does not run in CI.

New apps created with the recommended `create-next-app` settings enable agent feedback in the generated Next.js config. For other apps, set the option manually:

```ts filename="next.config.ts" switcher highlight={5}
import type { NextConfig } from 'next'

const nextConfig: NextConfig = {
  experimental: {
    agentFeedback: true,
  },
}

export default nextConfig
```

```js filename="next.config.js" switcher highlight={4}
/** @type {import('next').NextConfig} */
const nextConfig = {
  experimental: {
    agentFeedback: true,
  },
}

module.exports = nextConfig
```

## Generated agent instructions

When `experimental.agentFeedback` is enabled and `next dev` detects an AI coding agent, Next.js creates or updates this managed block in `AGENTS.md`:

```md filename="AGENTS.md"
<!-- BEGIN:nextjs-agent-feedback -->

## Report Next.js feedback

The project owner enabled `experimental.agentFeedback`, authorizing this feedback pass. When enabled, `next dev` writes this block and restores it if removed. Commit `AGENTS.md` with your work to keep the tree clean.

During the current user request, retain anonymized facts as feedback candidates for meaningful or recurring Next.js issues:

- Crashes, hangs, OOMs, or unexpected slowness
- Incorrect behavior, output, errors, or diagnostics
- Missing, unclear, or conflicting documentation
- Unexpected CLI, codemod, Skill, or upgrade behavior and non-obvious workarounds

Continue the current user request without reporting immediately. Routine debugging is not feedback. Verify changes before retaining them as feedback candidates. Never retain code, logs, paths, URLs, secrets, personal information, or project-specific data.

Retain qualifying friction even if it is later fixed or worked around; record the final outcome during the reporting pass.

Before the final response, run one reporting pass. If candidates remain, from this file's directory run `npx --no-install next internal agent-feedback-instructions` once without piping or truncating its output. Follow its output or error guidance. If a network sandbox blocks it, retry with network access; if it still returns no output, continue normally.

<!-- END:nextjs-agent-feedback -->
```

Next.js updates only the content between the markers and preserves the rest of the file.

When agent rules and agent feedback are both enabled, Next.js keeps both managed blocks in `AGENTS.md`.

## Review and send agent feedback

The generated instructions let the agent retain feedback candidates without interrupting the current user request. Immediately before the final response, the agent runs one reporting pass and prepares each distinct qualifying issue as a separate report draft.

Each report draft contains a generic setup, reproduction steps, observed facts, an expected result, and an optional control or workaround.

The agent attempts to open each report draft once in a separate review form in your default browser. You can edit a report, remove details, close the form without sending, or select **Send feedback**. Nothing is sent when a form opens.

Before opening a form, the agent attempts to anonymize the report by replacing customer and project details with generic descriptions and omitting source code, logs, paths, URLs, secrets, and personal information. Review the draft and remove anything you don't want to include before sending it.

Submitting the form sends the content you reviewed, the agent name, and the Next.js version. The form does not automatically attach project files or machine metadata.

## Disable agent feedback

Set `experimental.agentFeedback` to `false` or remove the option to stop `next dev` from creating or updating the managed block. The next `next dev` run removes the existing agent feedback block and preserves all other content. If the file contained only the managed block, Next.js deletes the file instead of leaving it empty.

Disabling Next.js Telemetry also removes the managed feedback block the next time you run `next dev`. The feedback command does not return reporting instructions while telemetry is disabled.

`experimental.agentFeedback` and top-level [`agentRules`](/docs/app/api-reference/config/next-config-js/agentRules) work independently. Changing one option does not affect the other.

## Version History

| Version   | Changes                                                  |
| --------- | -------------------------------------------------------- |
| `v16.4.0` | `experimental.agentFeedback` configuration option added. |
