---
title: Codemods
description: Use codemods to upgrade your Next.js codebase when new features are released.
source: app/guides/upgrading/codemods
---

{/* DO NOT EDIT. The content of this doc is generated from the source above. To edit the content of this page, navigate to the source page in your editor. You can use the `<PagesOnly>Content</PagesOnly>` component to add content that is specific to the Pages Router. Any shared content should not be wrapped in a component. */}
