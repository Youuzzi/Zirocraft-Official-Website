---
title: adapterPath
description: Configure a custom adapter for Next.js to hook into the build process.
source: app/api-reference/config/next-config-js/adapterPath
---

{/* DO NOT EDIT. The content of this doc is generated from the source above. To edit the content of this page, navigate to the source page in your editor. You can use the `<PagesOnly>Content</PagesOnly>` component to add content that is specific to the Pages Router. Any shared content should not be wrapped in a component. */}
